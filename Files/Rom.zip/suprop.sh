#!/system/bin/sh

sed -i '/^ro.on.core.versionrom/d' /system_root/system/build.prop
sed -i '/^ro.on.core.buildrom/d' /system_root/system/build.prop
sed -i '/^ro.system.build.version.sdk/a ro.on.core.versionrom=1.1.00' /system_root/system/build.prop
sed -i '/^ro.system.build.version.sdk/a ro.on.core.buildrom=20240326' /system_root/system/build.prop
