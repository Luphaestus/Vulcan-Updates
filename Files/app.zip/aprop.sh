#!/system/bin/sh

sed -i '/^ro.on.core.versionapp/d' /system_root/system/build.prop
sed -i '/^ro.on.core.buildapp/d' /system_root/system/build.prop

sed -i '/^ro.system.build.version.sdk/a ro.on.core.versionapp=1.0.10    ' /system_root/system/build.prop
sed -i '/^ro.system.build.version.sdk/a ro.on.core.buildapp=20240225' /system_root/system/build.prop
