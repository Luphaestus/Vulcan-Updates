#!/system/bin/sh

sed -i '/^ro.on.core.versionsu/d' /system_root/system/build.prop
sed -i '/^ro.on.core.buildsu/d' /system_root/system/build.prop
sed -i '/^ro.on.core.versionek/d' /system_root/system/build.prop
sed -i '/^ro.on.core.buildek/d' /system_root/system/build.prop
sed -i '/^ro.on.core.versionksu/d' /system_root/system/build.prop
sed -i '/^ro.on.core.buildksu/d' /system_root/system/build.prop

sed -i '/^ro.system.build.version.sdk/a ro.on.core.versionsu=1.0.00' /system_root/system/build.prop
sed -i '/^ro.system.build.version.sdk/a ro.on.core.buildsu=20240224' /system_root/system/build.prop
