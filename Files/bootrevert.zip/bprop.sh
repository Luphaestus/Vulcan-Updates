#!/system/bin/sh

sed -i '/^ro.on.core.versionboot/d' /system_root/system/build.prop
sed -i '/^ro.on.core.buildboot/d' /system_root/system/build.prop

