#!/system/bin/sh

sed -i '/^ro.on.core.versionboot/d' /system_root/system/build.prop
sed -i '/^ro.on.core.buildboot/d' /system_root/system/build.prop

sed -i '/^ro.system.build.version.sdk/a ro.on.core.versionboot=1.0.00' /system_root/system/build.prop
sed -i '/^ro.system.build.version.sdk/a ro.on.core.buildboot=20240224' /system_root/system/build.prop
