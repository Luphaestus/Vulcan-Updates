#!/system/bin/sh
# Change this path to wherever the keycheck binary is located in your installer
KEYCHECK=/tmp/keycheck
chmod 755 $KEYCHECK


choose() {
  #note from chainfire @xda-developers: getevent behaves weird when piped, and busybox grep likes that even less than toolbox/toybox grep
  while true; do
    /system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $INSTALLER/events
    if (`cat $INSTALLER/events 2>/dev/null | /system/bin/grep VOLUME >/dev/null`); then
      break
    fi
  done
  if (`cat $INSTALLER/events 2>/dev/null | /system/bin/grep VOLUMEUP >/dev/null`); then
    return 0
  else
    return 1
  fi
}


FUNCTION=choose

if $FUNCTION; then
    exit 0
else
    exit 1
fi

